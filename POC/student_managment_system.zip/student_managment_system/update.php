<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Update form</title>
		<!--External css file-->
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	</head>
	<body>
		<div class="header">
			<h2>Register here</h2>
		</div>
		<div class="rbox">
			<!--Update form for student on submit data goes to updateinfo.post-->
			<form action="updateinfo.php" method="post"> 
				<table cellspacing="20">   
					
					<tr><td>Password:</td><td> <input type="password" name="password" required/></td></tr>
					<tr><td>Name:</td><td> <input type="text" name="name" required/></td></tr>
					<tr><td>DOB:</td><td> <input type="text" name="dob" /></td></tr>
					<tr><td>Email:</td><td> <input type="text" name="email" required/></td></tr>
					
				</table>
				<input type="submit" name="submit" value="Update">
			</form>
		</div>
		
		<div class="footer">
			<br><br>
		</div>
	
	</body>
</html>