<?php
	session_start();
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_managment";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$stmt = $conn->prepare("UPDATE student SET password = ?, student_name = ?, dob = ?, email = ? WHERE username = ? ");
$stmt->bind_param("sssss", $password, $name, $dob, $email, $username);
// set parameters and execute
$password = md5($_POST['password']);
$name = $_POST['name'];
$dob = $_POST['dob'];
$email = $_POST['email'];
$username = $_SESSION['name'];
//executes
$stmt->execute();
echo "<h1>Info about &nbsp;&nbsp;".$_POST['name']."&nbsp;&nbsp;updated</h1>";
//closing database connection
$conn->close();
?>

