
<?php
// define variables and set to empty values
$unameErr =$passwordErr=$nameErr=$DobErr=$emailErr ="";
static $flag="true";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 // check if name only contains letters and whitespace
	if (!preg_match("/^[a-zA-Z ]*$/",$_POST['name'])) {
      $nameErr = "Only letters and white space allowed"; 
	  $flag=false;
    } 
	
    // check if e-mail address is well-formed
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
	  $flag=false;
    }
}
//if flag is true below code is executed
if($flag)
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_managment";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// prepare and bind
$stmt = $conn->prepare("INSERT INTO student(username, password, student_name, dob, email) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $username, $password, $name, $dob, $email );

// set parameters and execute
$username = $_POST['username'];
$password = md5($_POST['password']);
$name = $_POST['name'];
$dob = $_POST['dob'];
$email = $_POST['email'];
//executes
$stmt->execute();

echo "New record created successfully";
//closing prepared statment
$stmt->close();
//closing database connection
$conn->close();
}
//if flag is false below code is executed
else
{
	include 'register.html';
}
?>