<?php
// Start the session
session_start();
?>
<html>
	<head>
		<style>
			table, th, td {
				border: 1px solid black;
				border-collapse: collapse;
			}
		</style>
	</head>
	<body>
	<?php
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "student_managment";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT * FROM student";
		$result = $conn->query($sql);
		static $flag = false;

		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				if( $row["password"] == $_POST["password"] && $row["username"] == $_POST['name']) {
					$flag = true;
					$_SESSION['name']=$_POST['name'];
					break;
				}
				else {
					$flag = false;
				}
			}
			if($flag){
				echo "Welcome ".$row["student_name"]."<br><br>";
		
				echo "<table cellpadding=\"10\"><th>USERNAME</th> <th>NAME</th> <th>Date of Birth</th> <th>Email</th></tr>";
				echo "<tr><td>".$row["username"]."</td><td>".$row["student_name"]."</td><td>".$row["dob"]."</td><td>".$row["email"]."</td></tr></table>";
			}
			else {
				echo "Wrong username and password!";
			}

		} else {
			echo "No  user found!";
		}
		$conn->close();
	?>
	</body>
</html>