<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_managment";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
// prepare and bind
$stmt = $conn->prepare("DELETE FROM student WHERE username=?");

// set parameters
$stmt->bind_param("s", $username);
$username = $_POST['name'];

//Retrive username from student
$sql = "SELECT username FROM student";
$result = $conn->query($sql);
static $flag=false;
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		if($row['username']==$username){
			//  execute 
			$stmt->execute();
			$flag=true;
			
			break;
		}
		else
		{
			$flag=false;
		}	
	}
	if($flag)
	{
		echo "Record deleted successfully"."<br><br>";
     
	}
	else{
			echo "unvalid username"."<br><br>";
		   
	    }
}
else
	echo "No records found";
//closing database connection
$conn->close();
?>