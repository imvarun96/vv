<html>
	<head>
		<style>
			table, th, td {
				border: 1px solid black;
				border-collapse: collapse;
			}
		</style>
		
		<!--external css file-->
		<link rel="stylesheet"  href="style.css">
	</head>
	<body>
	<div class="header">
			<h2 style="text-align:center">Hogwarts school of wizadry</h2>
		</div>
	<?php
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "student_managment";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT * FROM admin";
		$result = $conn->query($sql);
		static $flag = false;

		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				if( md5($row["password"]) == md5($_POST["password"]) && $row["name"] == $_POST["name"]) {
					$flag = true;
					break;
				}
				else {
					$flag = false;
				}
			}
			//Below code is ececuted if flag is TRUE
			if($flag){
				echo "<h1>Welcome:".$row["name"]."</h1>";
				$sql = "SELECT * FROM student";
				$result = $conn->query($sql);
				
				if ($result->num_rows > 0) {
					
					echo "<table cellpadding=\"10\"><tr><th>USERNAME</th> <th>NAME</th> 
					      <th>EMAIL</th> <th>DOB</th></tr>";
						  //output data of each user
					while($row = $result->fetch_assoc()) {
						echo "<tr><td>".$row["username"]."</td><td>"
						      .$row["student_name"]."</td><td>".$row["dob"]."</td><td>".$row["email"]."</td></tr>";
						
					}
					echo "</table>";
				} 
				echo '<a href="register.html"><input type="button" value="Add a user"></a>';
				echo '<a href="delete.html"><input type="button" value="Delete"></a>';
			}
			        
			else {
				echo "Wrong username and password!";
			}

		} else {
			echo "No  user found!";
		}
		//closing database connection
		$conn->close();
	?>
	</body>
</html>